import * as React from 'react';
import { Text, View, StyleSheet, Image, LayoutAnimation, Platform, TouchableOpacity,UIManager, SafeAreaView, ScrollView, StatusBar, Button } from 'react-native';
import Constants from 'expo-constants';
import { NavigationContainer } from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';

function Hamburger(){
const [expanded4, setExpanded4]  = React.useState(false);
const [expanded5, setExpanded5]  = React.useState(false);

  return(
        <SafeAreaView style={styles.container}>
              <ScrollView style={styles.scrollbar}>

    <Text> Hello </Text>
 
)}
  </ScrollView>

    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  scrollbar:{
padding: 75,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    alignItems: 'center',

  },
  paragraph: {
    margin: 12,
    fontSize: 33,
    fontWeight: 'bold',
    textAlign: 'center',
  },
    ingredients: {
    margin: 24,
    fontSize: 25,
    textAlign: 'center',
    color : 'blue'
  },
    tinyLogo: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1

  },
    fixToText: {
    flexDirection: 'row',
    justifyContent: 'space-between',

  },
  title:{
    color : 'black',
    fontSize : 20,

  },
  timetomake:{

    fontSize: 25,
    textAlign: 'center',
    color : 'grey'
  },
  credits:{
   margin: 12,
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
    button: {
    backgroundColor: '#859a9b',
    borderRadius: 20,
    padding: 10,
    marginBottom: 20,
    shadowColor: '#303838',
    shadowOffset: { width: 0, height: 5 },
    shadowRadius: 10,
    shadowOpacity: 0.35,
  },
  
});