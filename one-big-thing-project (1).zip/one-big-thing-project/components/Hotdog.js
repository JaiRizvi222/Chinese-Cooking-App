import * as React from 'react';
import { Text, View, StyleSheet, Image, LayoutAnimation, Platform, TouchableOpacity,UIManager, SafeAreaView, ScrollView, StatusBar, Button } from 'react-native';
import Constants from 'expo-constants';


export default function App() {
 
 //This is the consant for each dropdown menu
const [expanded, setExpanded]  = React.useState(false);
const [expanded1, setExpanded1]  = React.useState(false);
const [expanded2, setExpanded2]  = React.useState(false);
const [expanded3, setExpanded3]  = React.useState(false);
const [expanded4, setExpanded4]  = React.useState(false);
const [expanded5, setExpanded5]  = React.useState(false);
 
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollbar}>
<Text style={styles.paragraph}>
        做很好吃的热狗!</Text>
        
                    <Text style={styles.timetomake}>
        时间：十分钟</Text>
            <Image
        style={{width: 250, height: 250}}
        source={{
          uri: 'https://cdn.leitesculinaria.com/wp-content/uploads/2021/05/perfect-hot-dog.jpg.optimal.jpg',
        }}
      />
      <TouchableOpacity onPress= {() => {LayoutAnimation.configureNext(LayoutAnimation.Presets.spring);
setExpanded2(!expanded2);
}
 
}>
<Text style={styles.ingredients}> {expanded2  ? "关闭" : "看配料."}</Text>
</TouchableOpacity>
 
{expanded2 &&(<View style = {styles.title}>
<Text style = {styles.title}> 你得用：</Text>
<Text style = {styles.title}> 一个香肠</Text>
<Text style = {styles.title}> 一个热狗面包</Text>
<Text style = {styles.title}> 一些番茄酱</Text>
<Text style = {styles.title}> 一些芥末</Text>
</View>
)}
<TouchableOpacity onPress= {() => {LayoutAnimation.configureNext(LayoutAnimation.Presets.spring);
setExpanded3(!expanded3);
}
 
}>
<Text style={styles.ingredients}> {expanded3 ? "关闭" : "看食谱."}</Text>
</TouchableOpacity>
 
{expanded3 &&(<View style = {styles.title}>
<Text style = {styles.title}> 如果你做一个热狗，你得：</Text>
<Text style = {styles.title}> 一）在锅里放水。热这个锅。</Text>
            <Image
        style={{width: 130, height: 130}}
        source={{
          uri: 'https://missvickie.com/wp-content/uploads/2020/10/water-not-boiling.jpg',
        }}
      />
<Text style = {styles.title}> 二）什么时候水沸腾了，放香肠在热水里。</Text>
            <Image
        style={{width: 130, height: 130}}
        source={{
          uri: 'https://thumbs.dreamstime.com/b/sausages-boiled-pan-boiling-water-close-up-shot-142208365.jpg',
        }}
      />
<Text style = {styles.title}> 三）沸腾以后，煮这个香肠五分钟。
</Text>
            <Image
        style={{width: 130, height: 130}}
        source={{
          uri: 'https://lilluna.com/wp-content/uploads/2020/02/how-to-boil-hot-dogs-resize-3.jpg',
        }}
      />
<Text style = {styles.title}> 四）放香肠在热狗面包里。</Text>
            <Image
        style={{width: 130, height: 130}}
        source={{
          uri: 'https://lilluna.com/wp-content/uploads/2020/02/how-to-boil-hot-dogs-resize-4.jpg',
        }}
      />
<Text style = {styles.title}> 五）放番茄酱或者芥末在那个热狗里。</Text>
            <Image
        style={{width: 130, height: 130}}
        source={{
          uri: 'https://www.readersdigest.ca/wp-content/uploads/2017/07/the-one-condiment-you-should-never-put-on-your-hot-dog.jpg',
        }}
      />
 
</View>

)}
  
<Text style = {styles.title}> </Text>


       <Text style = {styles.title}> </Text>
       <Text style = {styles.title}> </Text>
             <Text style = {styles.credits}>
       热狗：Kristyn Merkley
 
       
       </Text>
       <Text style = {styles.title}> </Text>
              <Text style = {styles.title}> </Text>
                     <Text style = {styles.title}> </Text>


  </ScrollView>
  
    </SafeAreaView>
  );
}


const styles = StyleSheet.create({
  scrollbar:{
padding: 75,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    alignItems: 'center',

  },
  paragraph: {
    margin: 12,
    fontSize: 33,
    fontWeight: 'bold',
    textAlign: 'center',
  },
    ingredients: {
    margin: 24,
    fontSize: 25,
    textAlign: 'center',
    color : 'blue'
  },
    tinyLogo: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1

  },
    fixToText: {
    flexDirection: 'row',
    justifyContent: 'space-between',

  },
  title:{
    color : 'black',
    fontSize : 20,

  },
  timetomake:{

    fontSize: 25,
    textAlign: 'center',
    color : 'grey'
  },
  credits:{
   margin: 12,
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
    button: {
    backgroundColor: '#859a9b',
    borderRadius: 20,
    padding: 10,
    marginBottom: 20,
    shadowColor: '#303838',
    shadowOffset: { width: 0, height: 5 },
    shadowRadius: 10,
    shadowOpacity: 0.35,
  },
  
});
