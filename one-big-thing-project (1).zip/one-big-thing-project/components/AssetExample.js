import * as React from 'react';
import { Text, View, StyleSheet, Image, LayoutAnimation, Platform, TouchableOpacity,UIManager, SafeAreaView, ScrollView, StatusBar, Button } from 'react-native';
import Constants from 'expo-constants';


export default function App() {
 
 //This is the consant for each dropdown menu
const [expanded, setExpanded]  = React.useState(false);
const [expanded1, setExpanded1]  = React.useState(false);
const [expanded2, setExpanded2]  = React.useState(false);
const [expanded3, setExpanded3]  = React.useState(false);
const [expanded4, setExpanded4]  = React.useState(false);
const [expanded5, setExpanded5]  = React.useState(false);
 
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollbar}>
 
      <Text style={styles.paragraph}>
        做很好吃的汉堡!</Text>
            <Text style={styles.timetomake}>
        时间：三十分钟</Text>
            <Image
        style={{width: 250, height: 250}}
        source={{
          uri: 'https://assets.epicurious.com/photos/5c745a108918ee7ab68daf79/5:4/w_3129,h_2503,c_limit/Smashburger-recipe-120219.jpg',
        }}
      />
 
      <TouchableOpacity onPress= {() => {LayoutAnimation.configureNext(LayoutAnimation.Presets.spring);//On the button press the animation is triggered
setExpanded(!expanded);
}
 
}>
 
<Text style={styles.ingredients}> {expanded ? "关闭" : "看配料."}</Text>
</TouchableOpacity>
 
{expanded &&(<View style = {styles.title}>
<Text style = {styles.title}> 你得用：</Text>
<Text style = {styles.title}> 半个洋葱</Text>
<Text style = {styles.title}> 一个大鸡蛋</Text>
<Text style = {styles.title}> 四个汉堡包的面包</Text>
<Text style = {styles.title}> 两个生菜叶</Text>
<Text style = {styles.title}> 一个番茄</Text>
<Text style = {styles.title}> 一些盐和胡椒</Text>
<Text style = {styles.title}> 一片美国奶酪</Text>
 
 
</View>
 
)}
<TouchableOpacity onPress= {() => {LayoutAnimation.configureNext(LayoutAnimation.Presets.spring);
setExpanded1(!expanded1);
}
 
}>
<Text style={styles.ingredients}> {expanded1 ? "关闭" : "看食谱."}</Text>
</TouchableOpacity>
 
{expanded1 &&(<View style = {styles.title}>
<Text style = {styles.title}> 如果你做四个汉堡包，你得：</Text>
<Text style = {styles.title}> 一）一个大鸡蛋，一磅牛肉，和半个洋葱在一个碗里混合.混合.</Text>
            <Image
        style={{width: 130, height: 130}}
        source={{
          uri: 'https://www.makeitgrateful.com/wp-content/uploads/2018/04/5D4B4507-Oven-baked-hamburgers-mixing-raw-beef-in-bowl-by-hand-1200x1800.jpg',
        }}
      />
<Text style = {styles.title}> 二）做四块牛肉。</Text>
            <Image
        style={{width: 130, height: 130}}
        source={{
          uri: 'https://www.seriouseats.com/thmb/dtlC87eVF8_b0q_u7Iimi3rHzvQ=/1500x1125/filters:no_upscale():max_bytes(150000):strip_icc()/20210607-INNOUTBURGERS-JANJIGIAN-seriouseats-10-8d9863a91dd04816b5c6a4a7fbd60b39.jpg',
        }}
      />
<Text style = {styles.title}> 三）在锅里烤牛肉八分钟或者九分钟。放起司在汉堡包里。</Text>
            <Image
        style={{width: 130, height: 130}}
        source={{
          uri: 'https://www.jessicagavin.com/wp-content/uploads/2020/03/stovetop-burgers-3-600x900.jpg',
        }}
      />
<Text style = {styles.title}> 四）在锅里烤汉堡包的面包三十秒或者一分钟。
</Text>
            <Image
        style={{width: 130, height: 130}}
        source={{
          uri: 'https://content.instructables.com/ORIG/FRP/K6Q7/ISX7KUQ4/FRPK6Q7ISX7KUQ4.jpg?auto=webp&fit=bounds&frame=1&height=1024&width=1024auto=webp&frame=1&height=300',
        }}
      />
<Text style = {styles.title}> 五）放汉堡包面包跟牛肉一起。
</Text>
            <Image
        style={{width: 130, height: 130}}
        source={{
          uri: 'https://www.washingtonpost.com/rf/image_982w/2010-2019/WashingtonPost/2018/05/22/Food/Images/washpostpicnic035lead.jpg',
        }}
      />
 
</View>
)}
  
<Text style = {styles.title}> </Text>


       <Text style = {styles.title}> </Text>
       <Text style = {styles.title}> </Text>
             <Text style = {styles.credits}>
       汉堡包：Recipes.com
       
       </Text>
       <Text style = {styles.title}> </Text>
              <Text style = {styles.title}> </Text>
                     <Text style = {styles.title}> </Text>


  </ScrollView>
  
    </SafeAreaView>
  );
}


const styles = StyleSheet.create({
  scrollbar:{
padding: 75,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    alignItems: 'center',

  },
  paragraph: {
    margin: 12,
    fontSize: 33,
    fontWeight: 'bold',
    textAlign: 'center',
  },
    ingredients: {
    margin: 24,
    fontSize: 25,
    textAlign: 'center',
    color : 'blue'
  },
    tinyLogo: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1

  },
    fixToText: {
    flexDirection: 'row',
    justifyContent: 'space-between',

  },
  title:{
    color : 'black',
    fontSize : 20,

  },
  timetomake:{

    fontSize: 25,
    textAlign: 'center',
    color : 'grey'
  },
  credits:{
   margin: 12,
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
    button: {
    backgroundColor: '#859a9b',
    borderRadius: 20,
    padding: 10,
    marginBottom: 20,
    shadowColor: '#303838',
    shadowOffset: { width: 0, height: 5 },
    shadowRadius: 10,
    shadowOpacity: 0.35,
  },
  
});
