import * as React from 'react';
import { Text, View, StyleSheet, Image, LayoutAnimation, Platform, TouchableOpacity,UIManager, SafeAreaView, ScrollView, StatusBar, Button } from 'react-native';
import Constants from 'expo-constants';


export default function Start2({navigation}){
  return(
        <SafeAreaView style={styles.container}>
              <ScrollView style={styles.scrollbar}>

            <Image
        style={{width: 250, height: 300}}
        source={{
          uri: 'https://img.freepik.com/free-psd/3d-female-character-with-superhero-cape-launching-into-flight_23-2148938887.jpg?size=338&ext=jpg',
        }}
      />
              <Text style={styles.credits}>好!我很高兴我可以给你我的最喜欢美国菜。我觉得这个菜是最好吃。</Text>

      <Button style={styles.paragraph}
        title="开始做美国菜!"
        onPress={()=>navigation.navigate("家的美国食谱")}
      />        




</ScrollView>
    </SafeAreaView>
  )
}


const styles = StyleSheet.create({
  scrollbar:{
padding: 75,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#afafaf',
    alignItems: 'center',

  },
  paragraph: {
    margin: 20,
    fontSize: 33,
    fontWeight: 'bold',
    textAlign: 'center',
  },
    ingredients: {
    margin: 24,
    fontSize: 25,
    textAlign: 'center',
    color : 'blue'
  },
    tinyLogo: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1

  },
    fixToText: {
    flexDirection: 'row',
    justifyContent: 'space-between',

  },
  title:{
    color : 'black',
    fontSize : 20,

  },
  timetomake:{

    fontSize: 25,
    textAlign: 'center',
    color : 'grey'
  },
  credits:{
   margin: 0,
    fontSize: 30,
    backgroundColor: '#f99083',

    textAlign: 'center',
    fontFamily: 'Montserrat',
    borderRadius: 20,
    padding: 10,
    marginBottom: 20,
    shadowColor: '#303838',
    shadowOffset: { width: 0, height: 5 },
    shadowRadius: 10,
    shadowOpacity: 0.35,
  },
    button: {
        flexDirection: 'row', 
        height: 50, 
        backgroundColor: 'yellow',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 50,
        elevation:3,
  },
  
});
