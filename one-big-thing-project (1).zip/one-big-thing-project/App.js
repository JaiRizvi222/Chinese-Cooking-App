import * as React from 'react';
import { Text, View, StyleSheet, Image, LayoutAnimation, Platform, TouchableOpacity,UIManager, SafeAreaView, ScrollView, StatusBar, Button } from 'react-native';
import Constants from 'expo-constants';
import { NavigationContainer } from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
//importing the different screens from the components folder
import Hamburger from './components/AssetExample'
import Hotdog from './components/Hotdog'
import Start from './components/Start'
import Start2 from './components/Start2'


//The screen that contains the button that navigate to the recipes. {navigation} means that this is a screen that can be used to navigate the screens
function HomeScreen({navigation}){
  return(
    //This line has a button that navigates to a screen that is defined later in the code. it is the line that starts with <TouchableOpacity
        <SafeAreaView style={styles.container}>
              <ScrollView style={styles.scrollbar}>

        <TouchableOpacity style={styles.button} onPress={()=>navigation.navigate("薯条")}>
            <Image
        style={{width: 200, height: 200}}
        source={{
          uri: 'https://media.istockphoto.com/photos/basket-of-famous-fast-food-french-fries-picture-id618214356?b=1&k=20&m=618214356&s=170667a&w=0&h=hBW1Ozw37xluDdo98v4U1JoRlU3elGRUIWFHmGUfmK8=',
        }}
      />
        </TouchableOpacity>
              <Text style={{ fontFamily: 'Montserrat', fontSize: 25 }}>时间：八十分钟</Text>
              <Text style={{ fontFamily: 'Montserrat', fontSize: 25 }}>麻烦: 三/十</Text>
                                   <Text style = {styles.title}> </Text>


        <TouchableOpacity style={styles.button} onPress={()=>navigation.navigate("汉堡包")}>
            <Image
        style={{width: 200, height: 200}}
        source={{
          uri: 'https://assets.epicurious.com/photos/5c745a108918ee7ab68daf79/5:4/w_3129,h_2503,c_limit/Smashburger-recipe-120219.jpg',
        }}
      />
        </TouchableOpacity>

              <Text style={{ fontFamily: 'Montserrat', fontSize: 25 }}>时间：三十分钟</Text>
              <Text style={{ fontFamily: 'Montserrat', fontSize: 25 }}>麻烦: 五/十</Text>     


                                   <Text style = {styles.title}> </Text>


        <TouchableOpacity style={styles.button} onPress={()=>navigation.navigate("热狗")}>
            <Image
        style={{width: 200, height: 200}}
        source={{
          uri: 'https://cdn.leitesculinaria.com/wp-content/uploads/2021/05/perfect-hot-dog.jpg.optimal.jpg',
        }}
      />
        </TouchableOpacity>

              <Text style={{ fontFamily: 'Montserrat', fontSize: 25 }}>时间：十分钟</Text>
              <Text style={{ fontFamily: 'Montserrat', fontSize: 25 }}>麻烦: 一/十</Text>       


                                   <Text style = {styles.title}> </Text>
                                      <Text style = {styles.title}> </Text>
                                   <Text style = {styles.title}> </Text>
                                   <Text style = {styles.title}> </Text>


</ScrollView>
    </SafeAreaView>
  )
}








//the page that shows the recipe for fries
function Fries(){

   //This is the consant for each dropdown menu
const [expanded4, setExpanded4]  = React.useState(false);
const [expanded5, setExpanded5]  = React.useState(false);

  return(
        <SafeAreaView style={styles.container}>
              <ScrollView style={styles.scrollbar}>

     <Text style={styles.paragraph}>
        做很好吃的薯条！</Text>
                    <Text style={styles.timetomake}>
        时间：八十分钟</Text>
            <Image
        style={{width: 250, height: 250}}
        source={{
          uri: 'https://media.istockphoto.com/photos/basket-of-famous-fast-food-french-fries-picture-id618214356?b=1&k=20&m=618214356&s=170667a&w=0&h=hBW1Ozw37xluDdo98v4U1JoRlU3elGRUIWFHmGUfmK8=',
        }}
        //The line below makes it so when you press the button for the dropdown menu it makes the animation happen and it also drops the list down
      />
      <TouchableOpacity onPress= {() => {LayoutAnimation.configureNext(LayoutAnimation.Presets.spring);
setExpanded4(!expanded4);
}
//this line makes it so when the button is pressed and expanded4 happens the button changes the text to let you know that if you click it again it will close.
}>
<Text style={styles.ingredients}> {expanded4 ? "关闭" : "看配料."}</Text>
</TouchableOpacity>
 
{expanded4 &&(<View style = {styles.title}>
<Text style = {styles.title}> 你得用：</Text>
<Text style = {styles.title}> 两个土豆</Text>
<Text style = {styles.title}> 一个平底锅</Text>
<Text style = {styles.title}> 一些油</Text>
<Text style = {styles.title}> 一些盐</Text>
 
</View>
)}
<TouchableOpacity onPress= {() => {LayoutAnimation.configureNext(LayoutAnimation.Presets.spring);
setExpanded5(!expanded5);
}
 
}>
<Text style={styles.ingredients}> {expanded5 ? "关闭" : "看食谱."}</Text>
</TouchableOpacity>
 
{expanded5 &&(<View style = {styles.title}>
<Text style = {styles.title}> 一）切土豆。</Text>
            <Image
        style={{width: 130, height: 130}}
        source={{
          uri: 'https://www.seriouseats.com/thmb/BzkuSm6-yK06lSvCT1MEuT63R_o=/1500x1125/filters:no_upscale():max_bytes(150000):strip_icc()/__opt__aboutcom__coeus__resources__content_migration__serious_eats__seriouseats.com__2018__04__20180309-french-fries-vicky-wasik-knife-only-1500x1125-acd3fa167f134291929d9c2d457e7ad9.jpg',
        }}
      />
<Text style = {styles.title}> 二）放土豆在冷水里。在水里泡六十分钟。
</Text>
            <Image
        style={{width: 130, height: 130}}
        source={{
          uri: 'https://www.cookingclassy.com/wp-content/uploads/2019/01/french-fries-11.jpg',
        }}
      />
<Text style = {styles.title}> 三）用一些纸擦干这个土豆。
</Text>
            <Image
        style={{width: 130, height: 130}}
        source={{
          uri: 'https://www.cookingclassy.com/wp-content/uploads/2019/01/french-fries-12.jpg',
        }}
      />
<Text style = {styles.title}> 四）放油在一个平底锅里。热油到三百华氏度。</Text>
            <Image
        style={{width: 130, height: 130}}
        source={{
          uri: 'https://images.food52.com/B9_MtjkSiRLPd1Shsq1_ZkRszjM=/ad4fcb59-edc7-4f06-a9eb-2d09761d9d19--8422946000_d5d9a816bc_z.jpg',
        }}
      />
<Text style = {styles.title}> 五）放土豆在平底锅里。炸五分钟。热油到四百华氏度以后， 再炸五分钟</Text>
            <Image
        style={{width: 130, height: 130}}
        source={{
          uri: 'https://imagesvc.meredithcorp.io/v3/mm/image?url=https%3A%2F%2Fstatic.onecms.io%2Fwp-content%2Fuploads%2Fsites%2F19%2F2019%2F02%2F26%2FGettyImages-904094778-2000.jpg',
        }}
      />
<Text style = {styles.title}> 六）在薯条上撒盐。
            <Image
        style={{width: 130, height: 130}}
        source={{
          uri: 'https://www.centralfifetimes.com/resources/images/10362798.jpg?type=responsive-gallery-fullscreen',
        }}
      />
</Text>
       <Text style = {styles.title}> </Text>
       <Text style = {styles.title}> </Text>
                    <Text style = {styles.credits}>
       薯条: The Cozy Cook
       
       </Text>
       <Text style = {styles.title}> </Text>
 
</View>
 
)}
  </ScrollView>

    </SafeAreaView>
  )
}

//establishing the navigation system
const Stack = createStackNavigator()

export default function App() {
//this defines all the different screens and makes it so that they can be called upon to navigate to. The chinese characters are the header of the page.
  return (
<NavigationContainer>
  <Stack.Navigator initialRouteName="Home">
      <Stack.Screen name="你好!" component ={Start} />
      <Stack.Screen name="开始!" component ={Start2} />
    <Stack.Screen name="家的美国食谱" component ={HomeScreen} />
    <Stack.Screen name="薯条" component ={Fries} />
      <Stack.Screen name="汉堡包" component ={Hamburger} />
      <Stack.Screen name="热狗" component ={Hotdog} />



  </Stack.Navigator>
</NavigationContainer>
  )
}

const styles = StyleSheet.create({
  scrollbar:{
padding: 75,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    alignItems: 'center',

  },
  paragraph: {
    margin: 12,
    fontSize: 33,
    fontWeight: 'bold',
    textAlign: 'center',
  },
    ingredients: {
    margin: 24,
    fontSize: 25,
    textAlign: 'center',
    color : 'blue'
  },
    tinyLogo: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1

  },
    fixToText: {
    flexDirection: 'row',
    justifyContent: 'space-between',

  },
  title:{
    color : 'black',
    fontSize : 20,

  },
  timetomake:{

    fontSize: 25,
    textAlign: 'center',
    color : 'grey'
  },
  credits:{
   margin: 12,
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
    button: {
    backgroundColor: '#859a9b',
    borderRadius: 20,
    padding: 10,
    marginBottom: 20,
    shadowColor: '#303838',
    shadowOffset: { width: 0, height: 5 },
    shadowRadius: 10,
    shadowOpacity: 0.9,
  },
  
});
